# Guia de Deploy

Instruções para Railway (API) e Vercel (Web).
